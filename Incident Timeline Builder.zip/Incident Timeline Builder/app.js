let events = [];

document.addEventListener("DOMContentLoaded", () => {
    populateTime();
    loadFromLocal();
});

function populateTime() {
    const hour = document.getElementById("hour");
    const minute = document.getElementById("minute");
    for (let h = 0; h <= 23; h++) {
        let val = h.toString().padStart(2, '0');
        hour.innerHTML += `<option value="${val}">${val}</option>`;
    }
    for (let m = 0; m <= 59; m++) {
        let val = m.toString().padStart(2, '0');
        minute.innerHTML += `<option value="${val}">${val}</option>`;
    }
}

function addEvent() {
    const time = document.getElementById("hour").value + ":" + document.getElementById("minute").value;
    const source = document.getElementById("source").value;
    const action = document.getElementById("action").value;
    const severity = document.getElementById("severity").value;

    if (!action) return;

    events.push({ id: Date.now(), time, source, action, severity });
    events.sort((a, b) => a.time.localeCompare(b.time));
    
    render();
    saveToLocal();
    
    document.getElementById("action").value = "";
    document.getElementById("source").value = "";
}

function render() {
    const ul = document.getElementById("timeline");
    ul.innerHTML = "";

    events.forEach((e) => {
        const li = document.createElement("li");
        li.className = `sev-${e.severity}`; // Renklendirme sınıfını ekler
        
        li.innerHTML = `
            <div>
                <strong>${e.time}</strong> | ${e.action}<br>
                <small>${e.source || "Bilinmiyor"} | Önem: ${e.severity}</small>
            </div>
            <button class="remove-btn" onclick="removeEvent(${e.id})">Sil</button>
        `;
        ul.appendChild(li);
    });
}

function saveToLocal() {
    localStorage.setItem("timeline_data", JSON.stringify(events));
}

function loadFromLocal() {
    const saved = localStorage.getItem("timeline_data");
    if (saved) {
        events = JSON.parse(saved);
        render();
    }
}

function removeEvent(id) {
    events = events.filter(e => e.id !== id);
    render();
    saveToLocal();
}

function clearAll() {
    if(confirm("Tüm verileri silmek istediğinize emin misiniz?")) {
        events = [];
        localStorage.removeItem("timeline_data");
        render();
    }
}

function exportTimeline() {
    let text = "Incident Timeline Report\n------------------------\n\n";
    events.forEach(e => {
        text += `[${e.time}] - ${e.action} (${e.source}) [${e.severity}]\n`;
    });
    downloadFile(text, "incident_timeline.txt", "text/plain");
}

function exportJSON() {
    const dataStr = JSON.stringify(events, null, 2);
    downloadFile(dataStr, "incident_data.json", "application/json");
}

function downloadFile(content, fileName, contentType) {
    const blob = new Blob([content], { type: contentType });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = fileName;
    a.click();
}